# and, or, not

gas = False
encendido = True
edad = 18

# if gas and encendido:
#     print("puedes avanzar")

# if gas or encendido:
#     print("puedes avanzar")

# if not gas or encendido:
#     print("puedes avanzar")

# if gas and encendido or edad > 17:
#     print("puedes avanzar")

if gas and encendido and edad > 17:
    print("puedes avanzar")

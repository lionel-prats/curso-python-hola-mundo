# ref. video 83
import os
os.system('cls' if os.name == 'nt' else 'clear')


try:
    n1 = int(input("Ingresa primer número: "))
    asdasd
except ValueError as e:
    print("El numero ingresado no es valido")
# except Exception as e:
except NameError as e:
    print("ocurrio un error inesperado")

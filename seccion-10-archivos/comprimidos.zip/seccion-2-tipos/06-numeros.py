numero = 3  # integer
decimal = 1.2  # float

# 2 + 2i -> en matematicas, el numero i es === a la raiz cuadrada de -1 (ya que no existe ningun numero que, al cuadrado, nos de -1)
imaginario = 2 + 2j

print(14 + 3)
print(14 - 3)
print(14 * 3)
print(14 / 3)
print(14 // 3)
print(14 % 3)
print(3 ** 3)

numero += 2
print(numero)
numero -= 3
print(numero)
numero *= 7
print(numero)
numero //= 3
print(numero)

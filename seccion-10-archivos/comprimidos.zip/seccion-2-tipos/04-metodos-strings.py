animal = "   chanCHito feliz   "

print(animal.upper())
print(animal.lower())
print(animal.capitalize())
print(animal.strip().capitalize())
print(animal.title())
print(animal.strip())
print(animal.rstrip())
print(animal.lstrip())
print(animal.find("chi"))
print(animal.replace("nCHo", "j"))
print("nch" in animal.lower())
print("nch" not in animal.lower())

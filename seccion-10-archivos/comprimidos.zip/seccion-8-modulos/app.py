import os  # modulo estandar de py, instalado por default con el interprete


from usuarios.impuestos.utilidades import pagar_impuestos
# import usuarios

# os.system('cls' if os.name == 'nt' else 'clear')

pagar_impuestos()
# print(__name__)

# print(dir(usuarios))

# print(usuarios.gestion.__name__)
# print(usuarios.impuestos.__package__)
# print(usuarios.gestion.__path__)
# print(usuarios.impuestos.__file__)

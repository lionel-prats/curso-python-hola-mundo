import os
os.system('cls' if os.name == 'nt' else 'clear')

# mascotas = ["Wolfgang", "Pelusa", "Pulga", "Copito"]
# print(mascotas[0])
# mascotas[0] = "Bicho"
# print(mascotas[0])
# print(mascotas[:3])
# print(mascotas[1:4])
# print(mascotas[2:])
# print(mascotas[-1])
# print(mascotas[::2])
# print(mascotas[::3])
# print(mascotas[1::2])

numeros = list(range(21))
print(numeros)
# print(numeros[::2])  # indices pares
# print(numeros[1::2])  # indices impares

numeros2 = list(range(1, 21))
print(numeros2)
print(numeros2[::2])  # indices pares
print(numeros2[1::2])  # indices impares

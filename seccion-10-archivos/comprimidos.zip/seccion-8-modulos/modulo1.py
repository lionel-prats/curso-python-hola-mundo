def pyinfo():
    print("Soy una funcion existente en el modulo 'modulo1.py'")

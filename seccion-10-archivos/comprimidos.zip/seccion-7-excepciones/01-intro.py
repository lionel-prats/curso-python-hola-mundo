# ref. video 82
import os
os.system('cls' if os.name == 'nt' else 'clear')


try:
    n1 = int(input("Ingresa primer número: "))
    asdasd
except ValueError as e:
    print("El valor ingresado no es válido")
# except Exception as e:
except NameError as e:
    print("Ocurrio un error inesperado: ", e)

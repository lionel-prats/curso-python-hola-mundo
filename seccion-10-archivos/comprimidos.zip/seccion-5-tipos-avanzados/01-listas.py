numeros = [1, 2, 3]
letras = ["a", "b", "c"]
ceros = [0] * 10
cerosYUnos = [0, 1] * 10
alfanumerico = numeros + letras
rango = list(range(10))
rango2 = list(range(1, 11))
chars = list('hola mundo')

print(ceros)
print(cerosYUnos)
print(alfanumerico)
print(rango)
print(rango2)
print(chars)

# seguir por el v46 - manipulando listas

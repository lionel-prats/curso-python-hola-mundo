# x = input("")

# int()
# str()
# float()
# bool()

# falsy  -> "", 0, None
# truthy -> todos los demas tipos de dato
print(bool(""))
print(bool("0"))
print(bool(None))
print(bool(" "))
print(bool(0))

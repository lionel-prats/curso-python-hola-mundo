edad = 25

if edad >= 15 and edad <= 65:
    print("puede entrar a la piscina")

if 15 <= edad <= 65:
    print("puede entrar a la piscina")

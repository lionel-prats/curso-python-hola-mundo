"""Introducción a Python"""

MONO = "loco"
print(MONO)

A = 12
B = 13

import os
os.system('cls' if os.name == 'nt' else 'clear')
# ref. video 63

mensaje = "Hola mundo"

print(type(mensaje))

# Clase: es el plano de construcción
# Objeto: es una instancia de una clase

# Clase: es el plano de construcción de una casa
# Objeto: la casa construida

# Clase: Humano
# Objeto: Nicolas, Felipe, María, Juan...

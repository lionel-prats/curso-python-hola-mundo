import os
os.system('cls' if os.name == 'nt' else 'clear')

numeros = (1, 2, 3) + (4, 5, 6)
print(numeros)

punto = tuple([1, 2])
print(punto)

print(tuple("pingocho"))
print(list("pipo rossi"))

# seguir por v56 - Sets

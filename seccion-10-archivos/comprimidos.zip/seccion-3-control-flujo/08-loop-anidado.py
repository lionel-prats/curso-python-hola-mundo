for j in range(3):  # outer for/ outer loop
    for k in range(2):  # inner for / inner loop
        print(f"{j}, {k}")

# ref. v95

from pathlib import Path

# Raw String (para escapar los backslashes en Windows)
Path(r"c:\Archivos de Programa\Minecraft")

Path("/usr/bin")  # (Linux/Mac)
Path()
Path().home("one/__init__.py")

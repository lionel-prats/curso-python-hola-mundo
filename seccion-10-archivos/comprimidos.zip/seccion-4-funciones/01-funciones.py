def hola(nombre, apellido="walterio"):
    print(f"Hola {nombre} {apellido}")


hola("raul", "lavie")
hola("lionel", "prats")
hola("gertrudiz")


hola(apellido="forlan", nombre="diego")

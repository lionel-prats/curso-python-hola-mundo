nombre = "Lionel"
apellido = "Prats"
# nombre_completo = nombre + " " + apellido
nombre_completo = f"{nombre} {apellido}"
iniciales = f"{nombre[0]}-{apellido[0]}"
ecuacion = f"12 * 5 = {12 * 5}"
print(nombre_completo)
print(iniciales)
print(ecuacion)

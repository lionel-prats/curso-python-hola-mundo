def get_product(**datos):
    print(datos)
    print(datos["id"], " ", datos["serie"])


get_product(id="id", serie="NEO_018")
# get_product(id="id", descrip="Corrientes")

nombre_curso = "Ultimate Python"
nombre1 = "Lionel"
nombre2 = "Prats"
nombre3 = True
print(nombre_curso, nombre1, nombre2, nombre3)

edad = 67

if edad > 60:
    print("puede ver la pelicula con descuento")
elif edad > 18:
    print("puede ver la pelicula")
else:
    print("no puedes entrar")

print("Listo")

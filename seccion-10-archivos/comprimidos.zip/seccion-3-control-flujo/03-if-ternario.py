edad = 6

mensaje = "Es mayor" if edad > 17 else "es menor"
# if edad > 17:
#     mensaje = "es mayor"
# else:
#     mensaje = "es menor"

print(mensaje)

def suma(a, b):
    return a + b


print(f"La suma da {suma(10, 45)}")

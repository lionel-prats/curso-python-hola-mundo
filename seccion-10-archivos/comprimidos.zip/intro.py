"""Introducción a Python"""

print('hola')
print('hola ' * 4)
